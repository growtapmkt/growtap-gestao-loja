
import React from 'react';
import { BarChart3, TrendingUp, TrendingDown, Target, FileSpreadsheet, ChevronRight, ShoppingCart, PackageOpen, LayoutGrid } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, Cell } from 'recharts';

const data = [
  { name: '01 Out', revenue: 4200 },
  { name: '08 Out', revenue: 5800 },
  { name: '15 Out', revenue: 7200 },
  { name: '22 Out', revenue: 9800 },
  { name: '31 Out', revenue: 12500 },
];

const bestSellers = [
  { name: 'Silk Floral Blouse', units: 428, color: '#22c55e' },
  { name: 'Denim Jacket Retro', units: 312, color: '#3b82f6' },
  { name: 'Midi Wrap Dress', units: 284, color: '#f59e0b' },
  { name: 'High-Waist Trousers', units: 190, color: '#8b5cf6' },
  { name: 'Cashmere Scarf', units: 120, color: '#ec4899' },
];

const Reports: React.FC = () => {
  return (
    <div className="space-y-8 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Relatórios & Analytics</h2>
          <p className="text-slate-500">Monitoramento em tempo real do desempenho da sua boutique.</p>
        </div>
        <div className="flex gap-3">
          <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 text-slate-600 rounded-xl font-bold text-sm">
            01 Out - 31 Out, 2023
          </button>
          <button className="flex items-center gap-2 px-6 py-2 bg-green-500 text-white rounded-xl font-bold hover:bg-green-600 shadow-lg shadow-green-100 transition-all">
            <FileSpreadsheet size={18} />
            Exportar Relatório
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Faturamento Total', value: 'R$ 42.500,00', trend: '+12.5% vs mês ant.', icon: BarChart3, color: 'text-green-600', bg: 'bg-green-50' },
          { label: 'Total de Pedidos', value: '1.240', trend: '+8.2% vs mês ant.', icon: ShoppingCart, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: 'Estoque Parado', value: '15.4%', trend: 'Ação Necessária', icon: PackageOpen, color: 'text-red-600', bg: 'bg-red-50' },
          { label: 'Ticket Médio', value: 'R$ 34,27', trend: 'Estável', icon: Target, color: 'text-indigo-600', bg: 'bg-indigo-50' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between mb-4">
               <div className={`p-3 rounded-2xl ${stat.bg} ${stat.color}`}>
                 <stat.icon size={22} />
               </div>
               <span className={`text-[10px] font-black px-2 py-1 rounded-full ${stat.color} ${stat.bg}`}>
                 {stat.trend}
               </span>
            </div>
            <p className="text-sm font-bold text-slate-400 uppercase tracking-tight">{stat.label}</p>
            <p className="text-2xl font-black text-slate-800 mt-1">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h3 className="text-xl font-black text-slate-800">Vendas ao Longo do Tempo</h3>
              <p className="text-sm text-slate-500">Tendência de receita para o período selecionado</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 bg-green-500 rounded-full"></span>
              <span className="text-xs font-black text-slate-400">REVENUE</span>
            </div>
          </div>
          <div className="h-[350px] w-full">
            <ResponsiveContainer width="100%" height="100%">
               <LineChart data={data}>
                  <defs>
                    <linearGradient id="lineGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#22c55e" stopOpacity={0.1}/>
                      <stop offset="95%" stopColor="#22c55e" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontWeight: 600, fontSize: 12}} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontWeight: 600, fontSize: 12}} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '20px', border: 'none', boxShadow: '0 20px 25px -5px rgba(0,0,0,0.1)' }}
                  />
                  <Line type="monotone" dataKey="revenue" stroke="#22c55e" strokeWidth={5} dot={{r: 6, fill: '#22c55e', strokeWidth: 3, stroke: '#fff'}} activeDot={{r: 8}} />
               </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm flex flex-col">
          <h3 className="text-xl font-black text-slate-800 mb-6">Top Produtos Vendidos</h3>
          <div className="space-y-6 flex-1">
            {bestSellers.map((item, i) => (
              <div key={i} className="space-y-2">
                <div className="flex items-center justify-between text-sm font-bold">
                  <span className="text-slate-700">{item.name}</span>
                  <span className="text-slate-400">{item.units} units</span>
                </div>
                <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div className="h-full bg-green-500 rounded-full" style={{ width: `${(item.units / 500) * 100}%`, backgroundColor: item.color }}></div>
                </div>
              </div>
            ))}
          </div>
          <button className="w-full py-3 mt-8 text-green-600 font-bold text-sm hover:underline flex items-center justify-center gap-2">
            Ver Inventário Completo <ChevronRight size={16} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
         <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-black text-slate-800">Estoque Parado Recente</h3>
              <span className="bg-red-50 text-red-600 text-[10px] font-black px-2 py-1 rounded">AÇÃO NECESSÁRIA</span>
            </div>
            <div className="space-y-4">
               {[
                 { name: 'Winter Wool Coat', stock: '42 restando', cost: 'R$ 120/mo', img: 'https://picsum.photos/seed/coat/50/50' },
                 { name: 'Basic Cotton Tee', stock: '128 restando', cost: 'R$ 85/mo', img: 'https://picsum.photos/seed/basic/50/50' },
               ].map((item, i) => (
                 <div key={i} className="flex items-center gap-4 p-4 rounded-2xl hover:bg-slate-50 transition-colors">
                    <img src={item.img} className="w-14 h-14 rounded-2xl object-cover bg-slate-100" alt={item.name} />
                    <div className="flex-1">
                       <p className="font-bold text-slate-800">{item.name}</p>
                       <p className="text-xs text-slate-500">Última venda: {Math.floor(Math.random() * 60)} dias atrás</p>
                    </div>
                    <div className="text-right">
                       <p className="font-black text-slate-800 text-sm">{item.stock}</p>
                       <p className="text-[10px] text-red-500 font-bold uppercase tracking-tight">Custo parado: {item.cost}</p>
                    </div>
                 </div>
               ))}
            </div>
         </div>

         <div className="bg-slate-900 p-10 rounded-3xl text-white relative overflow-hidden flex flex-col items-center justify-center text-center">
            <div className="absolute top-0 right-0 p-10 opacity-10">
               <LayoutGrid size={120} />
            </div>
            <div className="w-20 h-20 bg-green-500 rounded-3xl flex items-center justify-center mb-6 shadow-2xl shadow-green-500/20">
               <TrendingUp size={40} className="text-white" />
            </div>
            <h3 className="text-2xl font-black mb-4">Automatizar Pedidos de Estoque?</h3>
            <p className="text-slate-400 max-w-xs mb-8">
              Baseado nos seus produtos mais vendidos, sugerimos repor "Silk Floral Blouse" nos próximos 3 dias.
            </p>
            <button className="px-10 py-4 bg-white text-slate-900 rounded-2xl font-black text-sm hover:scale-105 transition-transform">
               Criar Ordem de Compra
            </button>
         </div>
      </div>
    </div>
  );
};

export default Reports;
