
import React from 'react';
import { Landmark, TrendingUp, Plus, Minus, Share2, MoreHorizontal, CreditCard, Wallet, QrCode } from 'lucide-react';

const Cashier: React.FC = () => {
  const transactions = [
    { date: 'Hoje, 14:30', desc: 'Venda: Vestido Midi Floral', sub: 'Pedido #8821', category: 'VENDA DIRETA', method: 'Crédito', type: 'IN', value: 'R$ 289,90' },
    { date: 'Hoje, 11:15', desc: 'Fornecedor: Fábrica Têxtil Rio', sub: 'NF-e 1299', category: 'ESTOQUE', method: 'PIX', type: 'OUT', value: 'R$ 1.450,00' },
    { date: 'Hoje, 09:45', desc: 'Venda: Conjunto Alfaiataria', sub: 'Pedido #8820', category: 'VENDA DIRETA', method: 'Dinheiro', type: 'IN', value: 'R$ 420,00' },
    { date: 'Ontem, 17:50', desc: 'Conta de Luz - Maio/24', sub: 'Operacional', category: 'DESPESA FIXA', method: 'Débito Autom.', type: 'OUT', value: 'R$ 380,45' },
  ];

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 text-shadow-sm">Gestão de Caixa</h2>
          <p className="text-slate-500">Monitore e registre as atividades financeiras diárias da sua loja.</p>
        </div>
        <div className="flex gap-3">
          <button className="flex items-center gap-2 px-6 py-2.5 bg-green-500 text-white rounded-xl font-bold hover:bg-green-600 shadow-lg shadow-green-100 transition-all">
            <Plus size={20} />
            Lançar Entrada
          </button>
          <button className="flex items-center gap-2 px-6 py-2.5 bg-red-500 text-white rounded-xl font-bold hover:bg-red-600 shadow-lg shadow-red-100 transition-all">
            <Minus size={20} />
            Lançar Despesa
          </button>
          <button className="p-2.5 bg-white border border-slate-200 text-slate-400 rounded-xl hover:bg-slate-50 transition-colors">
            <Share2 size={20} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-green-50 p-8 rounded-3xl border border-green-200 relative overflow-hidden group">
          <div className="absolute -right-10 -bottom-10 opacity-5 group-hover:scale-110 transition-transform duration-700">
            <Landmark size={240} />
          </div>
          <div className="relative z-10 flex flex-col justify-between h-full">
            <div className="flex items-center justify-between mb-6">
              <p className="font-bold text-green-800 text-lg uppercase tracking-tight">Saldo Atual em Caixa</p>
              <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-green-600 shadow-sm">
                <Landmark size={24} />
              </div>
            </div>
            <div>
              <p className="text-6xl font-black text-slate-800 tracking-tighter">R$ 5.240,00</p>
              <div className="flex items-center gap-2 mt-2 text-green-600 font-bold">
                <TrendingUp size={20} />
                <span>+12% em relação a ontem</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <p className="font-bold text-slate-400 uppercase tracking-tight">Próximos Vencimentos</p>
          <div>
            <p className="text-4xl font-black text-red-500 tracking-tighter">R$ 1.150,00</p>
            <p className="text-sm font-medium text-slate-500 mt-1">Total de contas a pagar (7 dias)</p>
          </div>
          <button className="w-full py-3 bg-slate-50 text-slate-800 rounded-xl font-bold text-sm hover:bg-slate-100 transition-colors border border-slate-100 mt-4">
            Ver Cronograma
          </button>
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-2 border-b-2 border-transparent">
            {['Extrato', 'Entradas', 'Despesas', 'A Prazo'].map((tab, i) => (
              <button 
                key={tab} 
                className={`px-4 py-3 text-sm font-bold transition-all relative ${
                  i === 0 ? 'text-green-600' : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                {tab}
                {i === 0 && <span className="absolute bottom-0 left-0 w-full h-1 bg-green-500 rounded-full"></span>}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3">
             <div className="flex bg-slate-50 p-1 rounded-xl">
               {['Hoje', 'Ontem', 'Semana'].map((p, i) => (
                 <button key={p} className={`px-4 py-2 text-xs font-bold rounded-lg transition-all ${
                   i === 0 ? 'bg-white shadow-sm text-slate-800' : 'text-slate-400'
                 }`}>
                   {p}
                 </button>
               ))}
             </div>
             <button className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-50">
               Customizado
             </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50/50 text-slate-400 text-[10px] font-black uppercase tracking-widest">
                <th className="px-8 py-5">Data/Hora</th>
                <th className="px-8 py-5">Descrição</th>
                <th className="px-8 py-5">Categoria</th>
                <th className="px-8 py-5 text-center">Método</th>
                <th className="px-8 py-5 text-right">Valor</th>
                <th className="px-8 py-5 text-center">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {transactions.map((t, i) => (
                <tr key={i} className="group hover:bg-slate-50 transition-colors">
                  <td className="px-8 py-5">
                    <p className="text-sm font-bold text-slate-800">{t.date.split(',')[0]}</p>
                    <p className="text-xs text-slate-400 font-medium">{t.date.split(',')[1]}</p>
                  </td>
                  <td className="px-8 py-5">
                    <p className="text-sm font-bold text-slate-800">{t.desc}</p>
                    <p className="text-xs text-slate-400 font-medium">{t.sub}</p>
                  </td>
                  <td className="px-8 py-5">
                    <span className={`text-[9px] font-black px-2 py-1 rounded-md tracking-tighter ${
                      t.type === 'IN' ? 'bg-green-100 text-green-700' : 'bg-red-50 text-red-600'
                    }`}>
                      {t.category}
                    </span>
                  </td>
                  <td className="px-8 py-5">
                    <div className="flex flex-col items-center justify-center gap-1">
                      {t.method === 'Crédito' && <CreditCard size={14} className="text-slate-400" />}
                      {t.method === 'PIX' && <QrCode size={14} className="text-slate-400" />}
                      {t.method === 'Dinheiro' && <Wallet size={14} className="text-slate-400" />}
                      <span className="text-xs font-bold text-slate-500">{t.method}</span>
                    </div>
                  </td>
                  <td className="px-8 py-5 text-right">
                    <div className={`flex items-center justify-end gap-1 font-black text-lg tracking-tight ${
                      t.type === 'IN' ? 'text-green-500' : 'text-red-500'
                    }`}>
                      {t.type === 'IN' ? <Plus size={16} /> : <Minus size={16} />}
                      <span>{t.value}</span>
                    </div>
                  </td>
                  <td className="px-8 py-5 text-center">
                    <button className="p-2 text-slate-300 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-all">
                      <MoreHorizontal size={18} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="p-6 border-t border-slate-100 flex items-center justify-between text-sm">
          <p className="font-bold text-slate-400">Mostrando 4 de 24 lançamentos</p>
          <div className="flex items-center gap-2">
             <button className="w-8 h-8 rounded-lg border border-slate-200 text-slate-400 flex items-center justify-center hover:bg-slate-50 disabled:opacity-50">
               &lt;
             </button>
             <button className="w-8 h-8 rounded-lg bg-green-500 text-white font-bold">1</button>
             <button className="w-8 h-8 rounded-lg border border-slate-200 text-slate-600 font-bold hover:bg-slate-50">2</button>
             <button className="w-8 h-8 rounded-lg border border-slate-200 text-slate-600 font-bold hover:bg-slate-50">3</button>
             <button className="w-8 h-8 rounded-lg border border-slate-200 text-slate-400 flex items-center justify-center hover:bg-slate-50">
               &gt;
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cashier;
