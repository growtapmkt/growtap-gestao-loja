
import React from 'react';
import { ClipboardCheck, Clock, CheckCircle2, AlertCircle, Search, Plus, MoreHorizontal } from 'lucide-react';

const Conditionals: React.FC = () => {
  const stats = [
    { label: 'Condicionais Ativas', value: '24', trend: '+12% este mês', icon: ClipboardCheck, color: 'text-green-600', bg: 'bg-green-50' },
    { label: 'Retornos Pendentes', value: '8', trend: '4 itens atrasados', icon: Clock, color: 'text-orange-600', bg: 'bg-orange-50' },
    { label: 'Taxa de Conversão', value: '68%', trend: '+5% vs semana passada', icon: CheckCircle2, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'Receita Potencial', value: 'R$ 4.250', trend: 'Reservado em estoque', icon: AlertCircle, color: 'text-indigo-600', bg: 'bg-indigo-50' },
  ];

  const condicionais = [
    { customer: 'Alice Smith', id: '#4059', date: '24 Out, 2023', deadline: 'Atrasado (3 dias)', items: 4, value: 'R$ 840,00', status: 'OVERDUE' },
    { customer: 'Emma Thompson', id: '#4122', date: '26 Out, 2023', deadline: 'Em 1 dia', items: 2, value: 'R$ 320,00', status: 'PENDING' },
    { customer: 'Maria Davis', id: '#4135', date: '27 Out, 2023', deadline: '30 Out, 2023', items: 6, value: 'R$ 1.150,00', status: 'NEW' },
  ];

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Condicionais (Appro)</h2>
          <p className="text-slate-500">Gerencie itens com clientes para prova em casa e finalize vendas pendentes.</p>
        </div>
        <button className="flex items-center gap-2 px-6 py-3 bg-green-500 text-white rounded-xl font-bold hover:bg-green-600 shadow-lg shadow-green-100 transition-all">
          <Plus size={20} />
          Nova Condicional
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <div className="flex items-center gap-4 mb-3">
              <div className={`p-3 rounded-xl ${stat.bg} ${stat.color}`}>
                <stat.icon size={22} />
              </div>
              <p className="text-sm font-bold text-slate-400 uppercase tracking-tight">{stat.label}</p>
            </div>
            <p className="text-3xl font-black text-slate-800">{stat.value}</p>
            <p className={`text-xs mt-1 font-semibold ${stat.color}`}>{stat.trend}</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <button className="px-4 py-2 text-sm font-bold text-slate-600 hover:bg-slate-50 rounded-lg">Todos</button>
            <button className="px-4 py-2 text-sm font-bold bg-green-100 text-green-700 rounded-lg">Ativos</button>
            <button className="px-4 py-2 text-sm font-bold text-slate-600 hover:bg-slate-50 rounded-lg">Atrasados</button>
            <button className="px-4 py-2 text-sm font-bold text-slate-600 hover:bg-slate-50 rounded-lg">Finalizados</button>
          </div>
          <div className="relative flex-1 md:max-w-xs">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Pesquisar por cliente..." 
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-500/20 text-sm"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 text-slate-400 text-[10px] font-black uppercase tracking-widest">
                <th className="px-6 py-4">Cliente</th>
                <th className="px-6 py-4">Data Emissão</th>
                <th className="px-6 py-4">Prazo Devolução</th>
                <th className="px-6 py-4">Itens</th>
                <th className="px-6 py-4">Valor Total</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {condicionais.map((c, i) => (
                <tr key={i} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-500 font-black text-xs">
                        {c.customer.split(' ')[0][0]}{c.customer.split(' ')[1]?.[0] || ''}
                      </div>
                      <div>
                        <p className="text-sm font-bold text-slate-800">{c.customer}</p>
                        <p className="text-[10px] text-slate-400 font-medium">ID: {c.id}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm font-medium text-slate-600">{c.date}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <span className={`w-2 h-2 rounded-full ${c.status === 'OVERDUE' ? 'bg-red-500 animate-pulse' : 'bg-orange-500'}`}></span>
                      <p className={`text-sm font-bold ${c.status === 'OVERDUE' ? 'text-red-500' : 'text-orange-600'}`}>{c.deadline}</p>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm font-bold text-slate-600">{c.items} peças</td>
                  <td className="px-6 py-4 text-sm font-black text-slate-800">{c.value}</td>
                  <td className="px-6 py-4">
                    <span className={`text-[10px] font-black px-2 py-1 rounded-lg ${
                      c.status === 'OVERDUE' ? 'bg-red-100 text-red-600' : 
                      c.status === 'PENDING' ? 'bg-orange-100 text-orange-600' : 'bg-blue-100 text-blue-600'
                    }`}>
                      {c.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <button className="p-2 text-slate-400 hover:bg-slate-100 rounded-lg transition-colors">
                      <MoreHorizontal size={18} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="flex items-center justify-between p-4 bg-slate-800 text-white rounded-2xl shadow-xl shadow-slate-200 border-l-4 border-orange-500">
        <div className="flex items-center gap-4">
          <div className="p-2 bg-orange-500 rounded-full">
            <AlertCircle size={20} />
          </div>
          <p className="font-bold">8 Retornos pendentes requerem sua atenção hoje</p>
        </div>
        <button className="px-6 py-2 bg-white text-slate-800 rounded-xl font-bold hover:bg-slate-100 transition-colors">
          Ver Lista de Atrasados
        </button>
      </div>
    </div>
  );
};

export default Conditionals;
