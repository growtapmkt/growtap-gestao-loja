
import React, { useState } from 'react';
import { Search, UserPlus, Mail, Phone, MapPin, Calendar, Edit3, ShoppingBag, ClipboardList, TrendingUp, MoreVertical } from 'lucide-react';

const Customers: React.FC = () => {
  const [selectedClient, setSelectedClient] = useState(0);

  const clients = [
    { name: 'Sarah Jenkins', phone: '(555) 0123-4567', segment: 'VIP', status: 'active', spend: '$1,240.50', freq: '2.4 / Mo', returnRate: '5%', lastOrder: '2 Days ago' },
    { name: 'Emma Thompson', phone: '(555) 0987-6543', segment: 'GOLD', status: 'active' },
    { name: 'Maria Rodriguez', phone: '(555) 0444-1122', segment: 'NEW', status: 'active' },
    { name: 'Lisa Black', phone: '(555) 0333-2211', segment: 'BRONZE', status: 'active' },
  ];

  return (
    <div className="flex h-full flex-col md:flex-row gap-6">
      {/* Sidebar List */}
      <div className="w-full md:w-80 bg-white border border-slate-200 rounded-3xl overflow-hidden flex flex-col shadow-sm">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
           <h3 className="text-xl font-black text-slate-800">Clientes</h3>
           <button className="p-2 bg-green-500 text-white rounded-xl hover:bg-green-600 transition-colors">
             <UserPlus size={18} />
           </button>
        </div>
        <div className="p-4 bg-slate-50/50">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
            <input 
              type="text" 
              placeholder="Pesquisar por nome ou telefone..." 
              className="w-full pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-green-500/20 focus:outline-none"
            />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto divide-y divide-slate-50">
          {clients.map((c, i) => (
            <div 
              key={i} 
              onClick={() => setSelectedClient(i)}
              className={`p-4 cursor-pointer transition-all flex items-center gap-3 ${
                selectedClient === i ? 'bg-green-50/50 border-l-4 border-green-500' : 'hover:bg-slate-50'
              }`}
            >
              <div className="w-10 h-10 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-500 font-black text-xs">
                {c.name.split(' ')[0][0]}{c.name.split(' ')[1]?.[0] || ''}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                   <p className="text-sm font-bold text-slate-800 truncate">{c.name}</p>
                   <span className={`text-[8px] font-black px-1.5 py-0.5 rounded ${
                     c.segment === 'VIP' ? 'bg-green-100 text-green-700' : 
                     c.segment === 'GOLD' ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-500'
                   }`}>{c.segment}</span>
                </div>
                <p className="text-xs text-slate-400">{c.phone}</p>
              </div>
              {c.status === 'active' && <span className="w-2 h-2 bg-green-500 rounded-full"></span>}
            </div>
          ))}
        </div>
      </div>

      {/* Profile Detail */}
      <div className="flex-1 space-y-6">
        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-6">
            <div className="w-20 h-20 rounded-3xl bg-green-100 flex items-center justify-center text-green-600 font-black text-2xl shadow-inner shadow-green-500/10">
              SJ
            </div>
            <div>
              <div className="flex items-center gap-3">
                 <h2 className="text-3xl font-black text-slate-800">Sarah Jenkins</h2>
                 <span className="bg-green-100 text-green-600 text-[10px] font-black px-2 py-1 rounded-md">V.I.P CUSTOMER</span>
              </div>
              <div className="flex items-center gap-4 mt-2 text-slate-500 text-sm font-medium">
                 <div className="flex items-center gap-1.5"><MapPin size={16} /> New York, NY</div>
                 <div className="flex items-center gap-1.5"><Calendar size={16} /> Cliente desde Out 2022</div>
              </div>
            </div>
          </div>
          <div className="flex gap-3">
             <button className="flex items-center gap-2 px-6 py-2.5 bg-white border border-slate-200 rounded-xl font-bold text-slate-600 hover:bg-slate-50 transition-colors">
                <Edit3 size={18} />
                Editar Perfil
             </button>
             <button className="flex items-center gap-2 px-6 py-2.5 bg-green-500 text-white rounded-xl font-bold hover:bg-green-600 shadow-lg shadow-green-100 transition-all">
                Novo Pedido
             </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { label: 'Total Gastos', value: '$1,240.50', trend: 'LTV Saudável', color: 'text-slate-800' },
            { label: 'Freq. Compra', value: '2.4 / Mo', trend: 'Consistente', color: 'text-slate-800' },
            { label: 'Taxa Devolução', value: '5%', trend: 'Muito Baixa', color: 'text-slate-800' },
            { label: 'Última Compra', value: '2 Dias atrás', trend: 'Recentemente Ativa', color: 'text-slate-800' },
          ].map((stat, i) => (
            <div key={i} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
               <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">{stat.label}</p>
               <p className="text-2xl font-black text-slate-800">{stat.value}</p>
               <p className="text-xs font-bold text-green-500 mt-1">{stat.trend}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
           <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
              <div className="flex items-center gap-2 mb-8">
                 <Mail size={18} className="text-slate-400" />
                 <h4 className="font-bold text-slate-800 uppercase tracking-tight text-sm">Informações de Contato</h4>
              </div>
              <div className="space-y-6">
                 <div className="flex justify-between border-b border-slate-50 pb-4">
                   <span className="text-sm text-slate-400 font-bold uppercase tracking-tight">Email</span>
                   <span className="text-sm font-bold text-slate-700">sarah.jenkins@example.com</span>
                 </div>
                 <div className="flex justify-between border-b border-slate-50 pb-4">
                   <span className="text-sm text-slate-400 font-bold uppercase tracking-tight">Celular</span>
                   <span className="text-sm font-bold text-slate-700">(555) 0123-4567</span>
                 </div>
                 <div className="flex justify-between border-b border-slate-50 pb-4">
                   <span className="text-sm text-slate-400 font-bold uppercase tracking-tight">Aniversário</span>
                   <span className="text-sm font-bold text-slate-700">12 de Maio, 1992</span>
                 </div>
                 <div className="flex justify-between border-b border-slate-50 pb-4">
                   <span className="text-sm text-slate-400 font-bold uppercase tracking-tight">Endereço</span>
                   <span className="text-sm font-bold text-slate-700 text-right">452 Broadway Ave, Suite 12, NY</span>
                 </div>
              </div>
           </div>

           <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
              <div className="flex items-center gap-2 mb-8">
                 <TrendingUp size={18} className="text-slate-400" />
                 <h4 className="font-bold text-slate-800 uppercase tracking-tight text-sm">Estilo & Tamanhos</h4>
              </div>
              <div className="grid grid-cols-2 gap-4">
                 <div className="p-4 bg-slate-50 rounded-2xl">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-tight mb-1">Top Size</p>
                    <p className="font-bold text-slate-800">Médio (M)</p>
                 </div>
                 <div className="p-4 bg-slate-50 rounded-2xl">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-tight mb-1">Bottom Size</p>
                    <p className="font-bold text-slate-800">US 8</p>
                 </div>
                 <div className="p-4 bg-slate-50 rounded-2xl">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-tight mb-1">Shoes</p>
                    <p className="font-bold text-slate-800">39 EU</p>
                 </div>
                 <div className="p-4 bg-slate-50 rounded-2xl">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-tight mb-1">Colors</p>
                    <div className="flex gap-1.5 mt-1">
                       <span className="w-4 h-4 rounded-full bg-blue-400"></span>
                       <span className="w-4 h-4 rounded-full bg-slate-100"></span>
                       <span className="w-4 h-4 rounded-full bg-slate-800"></span>
                    </div>
                 </div>
              </div>
              <div className="mt-6 p-4 border border-dashed border-slate-200 rounded-2xl italic text-xs text-slate-500">
                "Prefere tecidos naturais como linho e seda. Sempre avisá-la sobre novas coleções Boho-chic."
              </div>
           </div>
        </div>

        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
           <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                 <ShoppingBag size={18} className="text-slate-400" />
                 <h4 className="font-bold text-slate-800 uppercase tracking-tight text-sm">Histórico de Compras</h4>
              </div>
              <button className="text-green-600 text-xs font-black hover:underline uppercase tracking-widest">Ver Todos</button>
           </div>
           <div className="overflow-x-auto">
              <table className="w-full text-left">
                 <thead className="bg-slate-50/50 text-slate-400 text-[10px] font-black uppercase tracking-widest">
                    <tr>
                       <th className="px-8 py-4">Order ID</th>
                       <th className="px-8 py-4">Data</th>
                       <th className="px-8 py-4">Itens</th>
                       <th className="px-8 py-4">Total</th>
                       <th className="px-8 py-4">Status</th>
                    </tr>
                 </thead>
                 <tbody className="divide-y divide-slate-50">
                    <tr className="hover:bg-slate-50 transition-colors">
                       <td className="px-8 py-5 text-sm font-bold text-slate-800">#ORD-9021</td>
                       <td className="px-8 py-5 text-sm text-slate-500">24 Out, 2023</td>
                       <td className="px-8 py-5 text-sm text-slate-700">Floral Midi Dress, Silk Scarf</td>
                       <td className="px-8 py-5 text-sm font-black text-slate-800">$245.00</td>
                       <td className="px-8 py-5"><span className="bg-green-100 text-green-700 text-[10px] font-black px-2 py-1 rounded">PAID</span></td>
                    </tr>
                    <tr className="hover:bg-slate-50 transition-colors">
                       <td className="px-8 py-5 text-sm font-bold text-slate-800">#ORD-8854</td>
                       <td className="px-8 py-5 text-sm text-slate-500">15 Set, 2023</td>
                       <td className="px-8 py-5 text-sm text-slate-700">Linen Blazer (Navy)</td>
                       <td className="px-8 py-5 text-sm font-black text-slate-800">$180.00</td>
                       <td className="px-8 py-5"><span className="bg-green-100 text-green-700 text-[10px] font-black px-2 py-1 rounded">PAID</span></td>
                    </tr>
                 </tbody>
              </table>
           </div>
        </div>

        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden p-8">
           <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-2">
                 <ClipboardList size={18} className="text-slate-400" />
                 <h4 className="font-bold text-slate-800 uppercase tracking-tight text-sm">Condicionais Ativas</h4>
              </div>
              <span className="bg-orange-100 text-orange-600 text-[10px] font-black px-2 py-1 rounded">1 RETORNO PENDENTE</span>
           </div>
           
           <div className="flex items-center gap-6 p-6 bg-slate-50 rounded-3xl border border-slate-100 relative group cursor-pointer hover:border-orange-200 transition-all">
              <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center text-orange-500 shadow-sm">
                <ClipboardList size={28} />
              </div>
              <div className="flex-1">
                 <p className="font-black text-slate-800 text-lg">Approval Pack #AP-429</p>
                 <div className="flex gap-4 mt-1 text-xs text-slate-500 font-medium">
                    <span>3 Itens em prova</span>
                    <span className="flex items-center gap-1 text-orange-600 font-bold"><Calendar size={12} /> Expira em 2 dias</span>
                 </div>
              </div>
              <div className="flex gap-2">
                 <button className="px-6 py-2.5 bg-white border border-slate-200 rounded-xl font-bold text-sm text-slate-700 hover:bg-slate-100 transition-colors">Ver Peças</button>
                 <button className="px-6 py-2.5 bg-green-500 text-white rounded-xl font-bold text-sm hover:bg-green-600 transition-colors">Converter Venda</button>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Customers;
