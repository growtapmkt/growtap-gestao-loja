
import React from 'react';
import { Mail, Lock, LogIn, Store, ShieldCheck, Headphones } from 'lucide-react';

interface LoginProps {
  onLogin: () => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  return (
    <div className="min-h-screen w-full bg-[#f8fafc] flex flex-col items-center justify-center p-6 relative overflow-hidden">
      {/* Abstract Background Shapes */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none overflow-hidden">
         <div className="absolute -top-[10%] -left-[10%] w-[40%] h-[40%] bg-green-200/20 rounded-full blur-[120px]"></div>
         <div className="absolute bottom-[0%] right-[0%] w-[50%] h-[50%] bg-green-100/30 rounded-full blur-[150px]"></div>
      </div>

      <div className="w-full max-w-md relative z-10 animate-in fade-in zoom-in duration-700">
        <div className="flex flex-col items-center gap-3 mb-10">
          <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center text-green-600 shadow-xl shadow-green-500/10">
            <Store size={32} />
          </div>
          <div className="text-center">
            <h1 className="text-3xl font-black text-slate-900 tracking-tight">Boutique Management</h1>
            <p className="text-slate-500 font-medium">Gestão de estoque, vendas e condicionais</p>
          </div>
        </div>

        <div className="bg-white p-10 rounded-[40px] shadow-2xl shadow-slate-200/50 border border-white">
           <div className="mb-8">
              <h2 className="text-2xl font-black text-slate-800">Acesse sua conta</h2>
              <p className="text-sm text-slate-500 mt-1">Bem-vinda de volta ao painel administrativo</p>
           </div>

           <form className="space-y-6" onSubmit={(e) => { e.preventDefault(); onLogin(); }}>
              <div className="space-y-2">
                 <label className="text-sm font-black text-slate-700 uppercase tracking-widest pl-1">E-mail</label>
                 <div className="relative group">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-green-500 transition-colors" size={20} />
                    <input 
                      type="email" 
                      placeholder="seuemail@exemplo.com" 
                      className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:outline-none focus:ring-4 focus:ring-green-500/10 focus:border-green-500 transition-all font-medium"
                      defaultValue="marina@boutique.com"
                    />
                 </div>
              </div>

              <div className="space-y-2">
                 <div className="flex items-center justify-between px-1">
                    <label className="text-sm font-black text-slate-700 uppercase tracking-widest">Senha</label>
                    <button type="button" className="text-xs font-bold text-green-600 hover:underline">Esqueci a senha?</button>
                 </div>
                 <div className="relative group">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-green-500 transition-colors" size={20} />
                    <input 
                      type="password" 
                      placeholder="••••••••" 
                      className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:outline-none focus:ring-4 focus:ring-green-500/10 focus:border-green-500 transition-all font-medium"
                      defaultValue="password123"
                    />
                 </div>
              </div>

              <div className="flex items-center gap-2 pl-1">
                 <input type="checkbox" id="remember" className="w-5 h-5 rounded-lg border-slate-200 text-green-500 focus:ring-green-500 cursor-pointer" />
                 <label htmlFor="remember" className="text-sm font-bold text-slate-600 cursor-pointer">Manter conectado</label>
              </div>

              <button className="w-full py-5 bg-green-500 text-white rounded-[24px] font-black text-lg shadow-xl shadow-green-500/30 hover:bg-green-600 hover:-translate-y-0.5 active:translate-y-0 transition-all flex items-center justify-center gap-3">
                 Entrar <LogIn size={24} />
              </button>
           </form>

           <div className="mt-8 pt-8 border-t border-slate-100 text-center">
              <p className="text-sm font-bold text-slate-400">Não tem acesso? <button className="text-green-600 hover:underline">Solicite aqui</button></p>
           </div>
        </div>

        <div className="mt-12 flex flex-col items-center gap-4">
           <div className="flex items-center gap-8 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">
              <div className="flex items-center gap-2"><ShieldCheck size={16} className="text-green-500" /> Ambiente Seguro</div>
              <div className="flex items-center gap-2"><Headphones size={16} className="text-green-500" /> Suporte 24/7</div>
           </div>
           <p className="text-[10px] font-bold text-slate-300">V2.4.0 • BUILT WITH STYLE</p>
        </div>
      </div>
    </div>
  );
};

export default Login;
