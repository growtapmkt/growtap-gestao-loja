
import React from 'react';
import { Search, Bell, Menu, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';

const Topbar: React.FC = () => {
  return (
    <header className="h-20 bg-white border-b border-slate-200 px-4 md:px-8 flex items-center justify-between sticky top-0 z-10">
      <div className="flex items-center gap-4 flex-1">
        <button className="md:hidden p-2 text-slate-600">
          <Menu size={24} />
        </button>
        <div className="max-w-md w-full relative hidden md:block">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Pesquisar pedidos, produtos ou clientes..." 
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500/20 focus:border-green-500 transition-all text-sm"
          />
        </div>
      </div>

      <div className="flex items-center gap-3 md:gap-6">
        <Link 
          to="/catalog" 
          target="_blank" 
          className="flex items-center gap-2 px-4 py-2 text-green-600 font-medium hover:bg-green-50 rounded-lg transition-colors text-sm"
        >
          <ExternalLink size={16} />
          <span>Catálogo Online</span>
        </Link>

        <button className="p-2 text-slate-500 hover:bg-slate-50 rounded-lg relative transition-colors">
          <Bell size={22} />
          <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-red-500 border-2 border-white rounded-full"></span>
        </button>

        <div className="h-8 w-[1px] bg-slate-200 hidden md:block"></div>

        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <p className="text-xs text-slate-400 font-medium">05 Mai, 2024</p>
            <p className="text-sm font-semibold text-slate-700">Moda Chic Boutique</p>
          </div>
          <button className="bg-green-500 text-white px-4 py-2 rounded-lg font-semibold text-sm hover:bg-green-600 shadow-lg shadow-green-100 transition-all">
            Novo Pedido
          </button>
        </div>
      </div>
    </header>
  );
};

export default Topbar;
