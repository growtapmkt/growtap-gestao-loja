
import React from 'react';
import { ShoppingBag, Search, Plus, Filter, MoreHorizontal, Eye, CreditCard, Banknote, QrCode } from 'lucide-react';

const Sales: React.FC = () => {
  const orders = [
    { id: '#ORD-7241', customer: 'Jane Doe', initial: 'JD', status: 'CONFIRMED', payment: 'Credit Card', value: '$124.00' },
    { id: '#ORD-7242', customer: 'Sarah Miller', initial: 'SM', status: 'PENDING', payment: 'Bank Transfer', value: '$89.50' },
    { id: '#ORD-7243', customer: 'Alice Lu', initial: 'AL', status: 'CONFIRMED', payment: 'Store Credit', value: '$210.00' },
    { id: '#ORD-7244', customer: 'Bella King', initial: 'BK', status: 'CANCELLED', payment: 'Credit Card', value: '$45.00' },
  ];

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Lista de Pedidos</h2>
          <p className="text-slate-500">Visualize e gerencie todas as transações da sua boutique.</p>
        </div>
        <button className="flex items-center gap-2 px-6 py-3 bg-green-500 text-white rounded-xl font-bold hover:bg-green-600 shadow-lg shadow-green-100 transition-all">
          <Plus size={20} />
          Novo Pedido
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { label: 'Total Pedidos Hoje', value: '42', trend: '+15%', color: 'text-green-600', bg: 'bg-green-50' },
          { label: 'Aprovações Pendentes', value: '12', trend: 'Ação Necessária', color: 'text-orange-600', bg: 'bg-orange-50' },
          { label: 'Volume de Vendas', value: '$1,240.00', trend: '+8%', color: 'text-blue-600', bg: 'bg-blue-50' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
             <div className="flex items-center justify-between mb-2">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{stat.label}</p>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${stat.bg} ${stat.color}`}>{stat.trend}</span>
             </div>
             <p className="text-3xl font-black text-slate-800">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="flex bg-slate-50 p-1 rounded-xl w-fit">
            {['Hoje', 'Esta Semana', 'Este Mês'].map((t, i) => (
              <button key={t} className={`px-6 py-2.5 text-xs font-bold rounded-lg transition-all ${
                i === 0 ? 'bg-white shadow-sm text-slate-800' : 'text-slate-400'
              }`}>{t}</button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-3">
             <div className="relative flex-1 min-w-[240px]">
               <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
               <input type="text" placeholder="Pesquisar pedidos..." className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-500/20" />
             </div>
             <button className="flex items-center gap-2 px-4 py-2.5 border border-slate-200 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-50">
               <Filter size={16} /> Status: Todos
             </button>
             <button className="flex items-center gap-2 px-4 py-2.5 border border-slate-200 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-50">
               <CreditCard size={16} /> Pagamento
             </button>
             <button className="px-6 py-2.5 bg-slate-800 text-white rounded-xl text-xs font-bold hover:bg-slate-900 transition-colors">
               Aplicar Filtros
             </button>
          </div>
        </div>

        <div className="overflow-x-auto">
           <table className="w-full text-left">
              <thead>
                 <tr className="bg-slate-50/50 text-slate-400 text-[10px] font-black uppercase tracking-widest">
                    <th className="px-8 py-5">Order ID</th>
                    <th className="px-8 py-5">Cliente</th>
                    <th className="px-8 py-5 text-center">Status</th>
                    <th className="px-8 py-5">Pagamento</th>
                    <th className="px-8 py-5 text-right">Valor</th>
                    <th className="px-8 py-5 text-center">Ações</th>
                 </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                 {orders.map((o, i) => (
                   <tr key={i} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-8 py-6 text-sm font-bold text-slate-500">{o.id}</td>
                      <td className="px-8 py-6">
                        <div className="flex items-center gap-3">
                           <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 font-black text-[10px] uppercase">{o.initial}</div>
                           <span className="text-sm font-bold text-slate-800">{o.customer}</span>
                        </div>
                      </td>
                      <td className="px-8 py-6 text-center">
                         <span className={`text-[10px] font-black px-2.5 py-1 rounded-lg ${
                           o.status === 'CONFIRMED' ? 'bg-green-100 text-green-700' :
                           o.status === 'PENDING' ? 'bg-orange-100 text-orange-700' : 'bg-red-100 text-red-700'
                         }`}>{o.status}</span>
                      </td>
                      <td className="px-8 py-6">
                         <div className="flex items-center gap-2 text-sm font-bold text-slate-600">
                            {o.payment === 'Credit Card' && <CreditCard size={14} className="text-slate-400" />}
                            {o.payment === 'Bank Transfer' && <QrCode size={14} className="text-slate-400" />}
                            {o.payment === 'Store Credit' && <Banknote size={14} className="text-slate-400" />}
                            <span>{o.payment}</span>
                         </div>
                      </td>
                      <td className="px-8 py-6 text-right text-lg font-black text-slate-800">{o.value}</td>
                      <td className="px-8 py-6 text-center">
                         <div className="flex items-center justify-center gap-2">
                            <button className="p-2 text-slate-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-all"><Eye size={18} /></button>
                            <button className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-all"><MoreHorizontal size={18} /></button>
                         </div>
                      </td>
                   </tr>
                 ))}
              </tbody>
           </table>
        </div>

        <div className="p-8 border-t border-slate-100 flex items-center justify-between">
           <p className="text-sm font-bold text-slate-400">Mostrando 1-4 de 240 pedidos</p>
           <div className="flex items-center gap-2">
              <button className="p-2 text-slate-400 hover:text-slate-800 disabled:opacity-30 transition-colors">&lt;</button>
              <button className="w-8 h-8 rounded-lg bg-green-500 text-white font-black">1</button>
              <button className="w-8 h-8 rounded-lg border border-slate-200 text-slate-600 font-bold hover:bg-slate-50">2</button>
              <button className="w-8 h-8 rounded-lg border border-slate-200 text-slate-600 font-bold hover:bg-slate-50">3</button>
              <button className="p-2 text-slate-400 hover:text-slate-800 transition-colors">&gt;</button>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Sales;
