
import React, { useState } from 'react';
import { Package, Search, Filter, Plus, Edit2, ChevronRight, AlertCircle, FileDown } from 'lucide-react';

const Inventory: React.FC = () => {
  const [activeTab, setActiveTab] = useState('all');

  const products = [
    { id: '1', name: 'Silk Wrap Dress', sku: 'ST-SWD-001', color: 'Emerald', stock: 45, status: 'NORMAL', price: 245.00, img: 'https://picsum.photos/seed/wrap/300/400', tags: ['NEW'] },
    { id: '2', name: 'Linen Trousers', sku: 'ST-LNT-024', color: 'Beige', stock: 8, status: 'LOW_STOCK', price: 180.00, img: 'https://picsum.photos/seed/linen/300/400', tags: ['LOW STOCK'] },
    { id: '3', name: 'Cotton Basic Tee', sku: 'ST-CBT-112', color: 'Sunshine', stock: 142, status: 'NORMAL', price: 85.00, img: 'https://picsum.photos/seed/tee/300/400', tags: [] },
    { id: '4', name: 'Wool Sweater', sku: 'ST-WLS-502', color: 'Charcoal', stock: 3, status: 'CRITICAL', price: 210.00, img: 'https://picsum.photos/seed/sweater/300/400', tags: ['LOW STOCK'] },
    { id: '5', name: 'Floral Maxi Skirt', sku: 'ST-FMS-098', color: 'Spring Bloom', stock: 22, status: 'NORMAL', price: 155.00, img: 'https://picsum.photos/seed/skirt/300/400', tags: [] },
    { id: '6', name: 'Classic Denim Jacket', sku: 'ST-DNM-044', color: 'Indigo', stock: 68, status: 'NORMAL', price: 290.00, img: 'https://picsum.photos/seed/denim/300/400', tags: [] },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Gestão de Estoque</h2>
          <p className="text-slate-500">Monitorando 1,248 produtos em 12 categorias</p>
        </div>
        <div className="flex gap-3">
          <button className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg bg-white text-slate-600 hover:bg-slate-50 transition-colors">
            <FileDown size={18} />
            Exportar CSV
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-lg font-bold hover:bg-green-600 shadow-lg shadow-green-100 transition-all">
            <Plus size={18} />
            Novo Produto
          </button>
        </div>
      </div>

      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row gap-4 items-center">
        <div className="flex-1 relative w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Pesquisar por SKU, nome ou categoria..." 
            className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-500/20 focus:border-green-500 transition-all text-sm"
          />
        </div>
        <div className="flex items-center gap-2 w-full md:w-auto">
          <select className="flex-1 md:w-40 px-3 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-sm focus:outline-none">
            <option>Todas Categorias</option>
            <option>Vestidos</option>
            <option>Blusas</option>
          </select>
          <select className="flex-1 md:w-40 px-3 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-sm focus:outline-none">
            <option>Status Estoque</option>
            <option>Em estoque</option>
            <option>Baixo</option>
          </select>
          <button className="px-6 py-2.5 bg-green-500 text-white rounded-xl font-bold hover:bg-green-600 transition-colors text-sm">
            Filtrar
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {products.map((p) => (
          <div key={p.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden group hover:border-green-500/50 transition-all cursor-pointer">
            <div className="aspect-[3/4] relative overflow-hidden bg-slate-100">
              <img src={p.img} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" alt={p.name} />
              <div className="absolute top-3 left-3 flex flex-col gap-2">
                {p.tags.includes('NEW') && (
                  <span className="bg-green-500 text-white text-[10px] font-black px-2 py-1 rounded">NEW</span>
                )}
                {p.tags.includes('LOW STOCK') && (
                  <span className="bg-red-500 text-white text-[10px] font-black px-2 py-1 rounded flex items-center gap-1">
                    <AlertCircle size={10} /> LOW STOCK
                  </span>
                )}
              </div>
              <button className="absolute bottom-3 right-3 p-2 bg-white/90 backdrop-blur rounded-lg shadow-lg text-slate-700 opacity-0 group-hover:opacity-100 transition-all translate-y-2 group-hover:translate-y-0">
                <Edit2 size={16} />
              </button>
            </div>
            <div className="p-5 space-y-2">
              <div className="flex items-start justify-between">
                <div>
                  <h4 className="font-bold text-slate-800 text-lg leading-tight group-hover:text-green-600 transition-colors">{p.name}</h4>
                  <p className="text-xs text-slate-500 font-medium">SKU: {p.sku} • {p.color}</p>
                </div>
              </div>
              
              <div className="pt-2 flex flex-wrap gap-1.5">
                {['P', 'M', 'G'].map(size => (
                  <span key={size} className="px-2 py-1 bg-slate-50 text-slate-400 border border-slate-100 rounded text-[10px] font-bold">SIZE: {size}</span>
                ))}
              </div>

              <div className="pt-4 flex items-center justify-between">
                <div>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Estoque Atual</p>
                  <p className={`text-lg font-black ${p.status === 'NORMAL' ? 'text-green-500' : 'text-red-500'}`}>
                    {p.stock} <span className="text-xs font-normal text-slate-400">unidades</span>
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Preço</p>
                  <p className="text-lg font-black text-slate-800">R$ {p.price.toFixed(2)}</p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="flex items-center justify-center pt-8 gap-2">
        <button className="p-2 bg-white border border-slate-200 rounded-lg text-slate-400 hover:text-slate-600 transition-colors">
          <ChevronRight className="rotate-180" size={20} />
        </button>
        <button className="w-10 h-10 bg-green-500 text-white rounded-lg font-bold">1</button>
        <button className="w-10 h-10 bg-white border border-slate-200 text-slate-600 rounded-lg font-bold hover:bg-slate-50 transition-colors">2</button>
        <button className="w-10 h-10 bg-white border border-slate-200 text-slate-600 rounded-lg font-bold hover:bg-slate-50 transition-colors">3</button>
        <button className="p-2 bg-white border border-slate-200 rounded-lg text-slate-400 hover:text-slate-600 transition-colors">
          <ChevronRight size={20} />
        </button>
      </div>
    </div>
  );
};

export default Inventory;
