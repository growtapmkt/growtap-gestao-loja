
import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Package, 
  ShoppingCart, 
  ClipboardCheck, 
  Users, 
  Wallet, 
  BarChart3, 
  Settings,
  LogOut,
  Store
} from 'lucide-react';

const Sidebar: React.FC = () => {
  const navItems = [
    { name: 'Dashboard', icon: LayoutDashboard, path: '/' },
    { name: 'Estoque', icon: Package, path: '/inventory' },
    { name: 'Vendas', icon: ShoppingCart, path: '/sales' },
    { name: 'Condicionais', icon: ClipboardCheck, path: '/conditionals' },
    { name: 'Clientes', icon: Users, path: '/customers' },
    { name: 'Caixa', icon: Wallet, path: '/cashier' },
    { name: 'Relatórios', icon: BarChart3, path: '/reports' },
  ];

  return (
    <div className="w-64 bg-white border-r border-slate-200 hidden md:flex flex-col">
      <div className="p-6 flex items-center gap-3">
        <div className="w-10 h-10 bg-green-500 rounded-xl flex items-center justify-center text-white">
          <Store size={24} />
        </div>
        <div>
          <h1 className="font-bold text-slate-800 leading-tight">Boutique Manager</h1>
          <p className="text-xs text-slate-500">Gestão de Loja</p>
        </div>
      </div>

      <nav className="flex-1 px-4 py-4 space-y-1">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) => 
              `flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                isActive 
                  ? 'bg-green-500 text-white font-medium shadow-lg shadow-green-100' 
                  : 'text-slate-600 hover:bg-slate-50'
              }`
            }
          >
            <item.icon size={20} />
            <span>{item.name}</span>
          </NavLink>
        ))}
      </nav>

      <div className="p-4 border-t border-slate-100 space-y-1">
        <NavLink
          to="/settings"
          className="flex items-center gap-3 px-4 py-3 rounded-lg text-slate-600 hover:bg-slate-50 transition-colors"
        >
          <Settings size={20} />
          <span>Configurações</span>
        </NavLink>
        <button className="flex items-center gap-3 px-4 py-3 w-full rounded-lg text-red-500 hover:bg-red-50 transition-colors text-left">
          <LogOut size={20} />
          <span>Sair</span>
        </button>
      </div>

      <div className="p-4 bg-slate-50 mt-auto">
        <div className="flex items-center gap-3">
          <img 
            src="https://picsum.photos/seed/user/40/40" 
            className="w-10 h-10 rounded-full border-2 border-white shadow-sm"
            alt="Profile" 
          />
          <div className="overflow-hidden">
            <p className="text-sm font-semibold text-slate-800 truncate">Marina Souza</p>
            <p className="text-xs text-slate-500 truncate">Gerente de Loja</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
