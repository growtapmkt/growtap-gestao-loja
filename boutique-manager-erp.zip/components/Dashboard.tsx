
import React from 'react';
import { Wallet, ShoppingBag, ClipboardList, AlertTriangle, ArrowUpRight, TrendingUp, Plus } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';

const data = [
  { name: 'Seg', vendas: 4000 },
  { name: 'Ter', vendas: 3000 },
  { name: 'Qua', vendas: 2000 },
  { name: 'Qui', vendas: 2780 },
  { name: 'Sex', vendas: 1890 },
  { name: 'Sab', vendas: 2390 },
  { name: 'Dom', vendas: 3490 },
];

const Dashboard: React.FC = () => {
  const stats = [
    { title: 'Caixa do Dia', value: 'R$ 4.250,00', trend: '+12.5%', icon: Wallet, color: 'text-green-600', bg: 'bg-green-50' },
    { title: 'Vendas Hoje', value: '24 Pedidos', trend: '+8%', icon: ShoppingBag, color: 'text-blue-600', bg: 'bg-blue-50' },
    { title: 'Pendentes (Condicional)', value: 'R$ 1.840,00', trend: '8 Ativos', icon: ClipboardList, color: 'text-orange-600', bg: 'bg-orange-50' },
    { title: 'Estoque Baixo', value: '12 Itens', trend: 'Ação Necessária', icon: AlertTriangle, color: 'text-red-600', bg: 'bg-red-50' },
  ];

  const recentSales = [
    { customer: 'Ana Paula S.', status: 'CONCLUÍDO', date: 'Hoje, 14:20', value: 'R$ 280,00' },
    { customer: 'Juliana Mendes', status: 'CONDICIONAL', date: 'Hoje, 11:45', value: 'R$ 450,00' },
    { customer: 'Carla Oliveira', status: 'CONCLUÍDO', date: 'Hoje, 09:15', value: 'R$ 159,90' },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Painel de Controle</h2>
          <p className="text-slate-500">Bem-vinda de volta, Marina. Veja o que está acontecendo hoje.</p>
        </div>
        <div className="flex gap-3">
          <button className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg bg-white text-slate-600 hover:bg-slate-50 transition-colors">
            Exportar PDF
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, idx) => (
          <div key={idx} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 rounded-xl ${stat.bg} ${stat.color}`}>
                <stat.icon size={24} />
              </div>
              <span className={`text-xs font-bold px-2 py-1 rounded-full ${stat.color} ${stat.bg}`}>
                {stat.trend}
              </span>
            </div>
            <p className="text-sm font-medium text-slate-500">{stat.title}</p>
            <p className="text-2xl font-bold text-slate-800 mt-1">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* Quick Actions */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <button className="flex items-center justify-center gap-3 p-6 bg-green-500 text-white rounded-2xl font-bold hover:bg-green-600 shadow-lg shadow-green-100 transition-all">
              <Plus size={24} />
              Nova Venda
            </button>
            <button className="flex items-center justify-center gap-3 p-6 bg-white border border-slate-200 text-slate-700 rounded-2xl font-bold hover:bg-slate-50 shadow-sm transition-all">
              <Plus size={24} />
              Nova Condicional
            </button>
            <button className="flex items-center justify-center gap-3 p-6 bg-white border border-slate-200 text-slate-700 rounded-2xl font-bold hover:bg-slate-50 shadow-sm transition-all">
              <Plus size={24} />
              Novo Produto
            </button>
          </div>

          {/* Vendas Recentes */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h3 className="font-bold text-slate-800">Vendas Recentes</h3>
              <button className="text-green-600 text-sm font-semibold hover:underline">Ver todas</button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-slate-50/50 text-slate-400 text-xs font-bold uppercase tracking-wider">
                    <th className="px-6 py-4">Cliente</th>
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4">Data</th>
                    <th className="px-6 py-4">Valor</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {recentSales.map((sale, i) => (
                    <tr key={i} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 font-bold text-xs uppercase">
                            {sale.customer.split(' ')[0][0]}{sale.customer.split(' ')[1]?.[0] || ''}
                          </div>
                          <span className="text-sm font-semibold text-slate-700">{sale.customer}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`text-[10px] font-bold px-2 py-1 rounded-md ${
                          sale.status === 'CONCLUÍDO' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'
                        }`}>
                          {sale.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-500">{sale.date}</td>
                      <td className="px-6 py-4 text-sm font-bold text-slate-800">{sale.value}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          {/* Charts or Insights */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-bold text-slate-800">Vendas da Semana</h3>
              <div className="p-2 bg-green-50 text-green-600 rounded-lg">
                <TrendingUp size={20} />
              </div>
            </div>
            <div className="h-[200px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data}>
                  <defs>
                    <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#22c55e" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <Area type="monotone" dataKey="vendas" stroke="#22c55e" strokeWidth={3} fillOpacity={1} fill="url(#colorSales)" />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
                    itemStyle={{ color: '#22c55e', fontWeight: 'bold' }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between text-sm">
              <span className="text-slate-500">Média diária</span>
              <span className="font-bold text-slate-800">R$ 2.840,00</span>
            </div>
          </div>

          {/* Attention Items */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
             <h3 className="font-bold text-slate-800 mb-4">Atenção Estoque</h3>
             <div className="space-y-4">
                {[
                  { name: 'Vestido Midi Floral', details: 'Tamanho P • 2 restando', img: 'https://picsum.photos/seed/dress1/50/50' },
                  { name: 'Blusa de Linho Bege', details: 'Tamanho M • 1 restando', img: 'https://picsum.photos/seed/blouse/50/50' },
                  { name: 'Calça Pantalona Preta', details: 'Tamanho G • 3 restando', img: 'https://picsum.photos/seed/pants/50/50' },
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-3 group cursor-pointer">
                    <img src={item.img} className="w-12 h-12 rounded-xl object-cover bg-slate-100" alt={item.name} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-slate-800 truncate">{item.name}</p>
                      <p className="text-xs text-slate-500">{item.details}</p>
                    </div>
                    <div className="text-red-500 opacity-0 group-hover:opacity-100 transition-opacity">
                      <AlertTriangle size={16} />
                    </div>
                  </div>
                ))}
             </div>
             <button className="w-full mt-6 py-2 border border-slate-200 rounded-lg text-sm font-semibold text-slate-600 hover:bg-slate-50 transition-colors">
               Gerenciar Estoque
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
