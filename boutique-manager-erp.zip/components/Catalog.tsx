
import React from 'react';
import { ShoppingCart, MessageCircle, Heart, Search, Filter, Facebook, Instagram, Twitter } from 'lucide-react';

const Catalog: React.FC = () => {
  const products = [
    { name: 'Floral Maxi Dress', price: 249.00, img: 'https://picsum.photos/seed/cat1/400/500', tag: 'NEW SEASON', colors: ['#ffccd5', '#ffffcc'], sizes: ['P', 'M', 'G'] },
    { name: 'Premium Linen Blazer', price: 389.00, img: 'https://picsum.photos/seed/cat2/400/500', tag: 'BEST SELLER', colors: ['#ffffff', '#000000'], sizes: ['M', 'G', 'GG'] },
    { name: 'Tailored Wide Leg Trousers', price: 195.00, img: 'https://picsum.photos/seed/cat3/400/500', tag: null, colors: ['#f5e6ca', '#2a5d4e'], sizes: ['36', '38', '40'] },
    { name: 'Casual Denim Shorts Set', price: 165.00, img: 'https://picsum.photos/seed/cat4/400/500', tag: '15% OFF', colors: ['#a2cffe'], sizes: ['38', '42'] },
  ];

  return (
    <div className="min-h-screen bg-slate-50 font-sans">
      <nav className="bg-white/80 backdrop-blur-md sticky top-0 z-50 border-b border-slate-200 px-4 md:px-8 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center text-white">
            <ShoppingCart size={18} />
          </div>
          <span className="font-black text-slate-800 text-xl tracking-tighter">Lumina Fashion</span>
        </div>

        <div className="hidden md:flex items-center flex-1 max-w-lg mx-8 relative">
          <Search className="absolute left-3 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="O que você está procurando hoje?" 
            className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-full focus:outline-none focus:ring-2 focus:ring-green-500/20"
          />
        </div>

        <div className="flex items-center gap-4">
          <button className="p-2 text-slate-600 hover:bg-slate-100 rounded-full transition-colors relative">
            <Heart size={24} />
          </button>
          <button className="p-2 text-slate-600 hover:bg-slate-100 rounded-full transition-colors relative">
            <ShoppingCart size={24} />
            <span className="absolute top-1 right-1 w-5 h-5 bg-green-500 text-white text-[10px] font-black rounded-full flex items-center justify-center border-2 border-white">
              0
            </span>
          </button>
        </div>
      </nav>

      {/* Hero Banner */}
      <div className="relative h-[60vh] md:h-[70vh] bg-slate-900 overflow-hidden">
        <img src="https://picsum.photos/seed/hero/1920/1080" className="w-full h-full object-cover opacity-50" alt="Hero" />
        <div className="absolute inset-0 flex flex-col justify-center items-center text-center p-8">
           <span className="bg-green-500 text-white text-xs font-black px-3 py-1 rounded-full mb-4 tracking-widest">NEW SEASON</span>
           <h1 className="text-5xl md:text-7xl font-black text-white tracking-tighter mb-4">Summer Collection 2024</h1>
           <p className="text-slate-300 max-w-xl text-lg mb-8 leading-relaxed">
             Discover the essence of elegance with our handcrafted linen and silk pieces designed for the modern woman.
           </p>
           <button className="px-10 py-4 bg-white text-slate-900 rounded-full font-black hover:scale-105 transition-transform shadow-2xl">
             Ver Coleção
           </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 py-12">
        <div className="flex flex-wrap items-center gap-3 mb-12">
          <button className="px-6 py-2.5 bg-green-500 text-white rounded-full font-black text-sm">All Items</button>
          <button className="px-6 py-2.5 bg-white border border-slate-200 text-slate-600 rounded-full font-bold text-sm hover:border-green-500 transition-colors">Dresses</button>
          <button className="px-6 py-2.5 bg-white border border-slate-200 text-slate-600 rounded-full font-bold text-sm hover:border-green-500 transition-colors">Blouses</button>
          <button className="px-6 py-2.5 bg-white border border-slate-200 text-slate-600 rounded-full font-bold text-sm hover:border-green-500 transition-colors">Accessories</button>
          <button className="ml-auto flex items-center gap-2 px-6 py-2.5 bg-white border border-slate-200 text-slate-600 rounded-full font-bold text-sm">
            <Filter size={18} /> Filters
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((p, i) => (
            <div key={i} className="group cursor-pointer">
              <div className="aspect-[4/5] bg-white rounded-3xl overflow-hidden relative mb-4 shadow-sm group-hover:shadow-2xl transition-all duration-500">
                <img src={p.img} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={p.name} />
                <button className="absolute top-4 right-4 p-3 bg-white/80 backdrop-blur rounded-full text-slate-800 opacity-0 group-hover:opacity-100 transition-all shadow-lg hover:bg-green-500 hover:text-white">
                  <Heart size={20} />
                </button>
                {p.tag && (
                  <span className={`absolute top-4 left-4 px-3 py-1 rounded text-[10px] font-black text-white ${
                    p.tag.includes('OFF') ? 'bg-red-500' : 'bg-slate-800'
                  }`}>
                    {p.tag}
                  </span>
                )}
                <div className="absolute bottom-4 inset-x-4">
                  <button className="w-full py-3 bg-green-500 text-white rounded-2xl font-black text-sm flex items-center justify-center gap-2 translate-y-12 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300 shadow-xl">
                    <MessageCircle size={18} /> WhatsApp
                  </button>
                </div>
              </div>
              <div className="space-y-1 px-2">
                 <div className="flex items-center justify-between">
                    <h3 className="font-bold text-slate-800 group-hover:text-green-600 transition-colors">{p.name}</h3>
                    <div className="flex gap-1">
                      {p.colors.map((c, j) => (
                        <span key={j} className="w-3 h-3 rounded-full border border-slate-100" style={{ backgroundColor: c }}></span>
                      ))}
                    </div>
                 </div>
                 <p className="font-black text-slate-900 text-lg">R$ {p.price.toFixed(2)}</p>
                 <div className="flex gap-1.5 mt-2">
                   {p.sizes.map(s => (
                     <span key={s} className="w-8 h-8 flex items-center justify-center bg-white border border-slate-100 rounded text-[10px] font-bold text-slate-400 group-hover:border-slate-300 transition-colors">{s}</span>
                   ))}
                 </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-20 text-center">
          <button className="px-12 py-4 border-2 border-slate-800 text-slate-800 font-black rounded-full hover:bg-slate-800 hover:text-white transition-all">
            View More Products
          </button>
        </div>
      </div>

      <footer className="bg-white border-t border-slate-200 mt-20 px-8 py-16">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="space-y-6">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-green-500 rounded-xl flex items-center justify-center text-white">
                <ShoppingCart size={22} />
              </div>
              <span className="font-black text-slate-800 text-2xl tracking-tighter">Lumina Fashion</span>
            </div>
            <p className="text-slate-500 leading-relaxed">
              Premium women's clothing curator. Quality fabrics and timeless designs for every occasion.
            </p>
          </div>

          <div>
            <h4 className="font-black text-slate-900 mb-6 uppercase tracking-widest text-xs">Quick Links</h4>
            <ul className="space-y-4 text-slate-500 font-medium">
              <li><a href="#" className="hover:text-green-500 transition-colors">How to order</a></li>
              <li><a href="#" className="hover:text-green-500 transition-colors">Size Guide</a></li>
              <li><a href="#" className="hover:text-green-500 transition-colors">Return Policy</a></li>
              <li><a href="#" className="hover:text-green-500 transition-colors">Contact Us</a></li>
            </ul>
          </div>

          <div>
             <h4 className="font-black text-slate-900 mb-6 uppercase tracking-widest text-xs">Visit Us</h4>
             <p className="text-slate-500 font-medium leading-relaxed">
               Av. Paulista, 1000 - São Paulo, SP<br />
               Mon-Fri: 9am - 6pm
             </p>
             <div className="flex gap-4 mt-6">
               <button className="p-3 bg-slate-50 text-slate-600 rounded-full hover:bg-green-500 hover:text-white transition-all"><Facebook size={20} /></button>
               <button className="p-3 bg-slate-50 text-slate-600 rounded-full hover:bg-green-500 hover:text-white transition-all"><Instagram size={20} /></button>
               <button className="p-3 bg-slate-50 text-slate-600 rounded-full hover:bg-green-500 hover:text-white transition-all"><Twitter size={20} /></button>
             </div>
          </div>

          <div className="bg-green-50 p-8 rounded-3xl text-center flex flex-col items-center justify-center border border-green-100">
             <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center text-green-500 shadow-xl shadow-green-100 mb-4 animate-bounce">
                <MessageCircle size={32} />
             </div>
             <h4 className="font-black text-green-900 text-xl mb-2">Can we help?</h4>
             <p className="text-green-700/70 text-sm mb-6">Our experts are online to help with your choices.</p>
             <button className="w-full py-3 bg-green-500 text-white rounded-2xl font-black text-sm hover:scale-105 transition-transform shadow-lg shadow-green-200">
               Start Chat
             </button>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Catalog;
