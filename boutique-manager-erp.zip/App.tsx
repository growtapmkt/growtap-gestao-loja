
import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Topbar from './components/Topbar';
import Dashboard from './components/Dashboard';
import Inventory from './components/Inventory';
import Sales from './components/Sales';
import Conditionals from './components/Conditionals';
import Customers from './components/Customers';
import Cashier from './components/Cashier';
import Reports from './components/Reports';
import Catalog from './components/Catalog';
import Login from './components/Login';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(true); // Mocked for now

  // Public Catalog check
  const isCatalogPage = window.location.hash.includes('/catalog');

  if (!isAuthenticated && !isCatalogPage) {
    return <Login onLogin={() => setIsAuthenticated(true)} />;
  }

  return (
    <Router>
      <div className="flex h-screen bg-slate-50 overflow-hidden">
        {!isCatalogPage && <Sidebar />}
        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          {!isCatalogPage && <Topbar />}
          <main className="flex-1 overflow-y-auto p-4 md:p-8">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/inventory" element={<Inventory />} />
              <Route path="/sales" element={<Sales />} />
              <Route path="/conditionals" element={<Conditionals />} />
              <Route path="/customers" element={<Customers />} />
              <Route path="/cashier" element={<Cashier />} />
              <Route path="/reports" element={<Reports />} />
              <Route path="/catalog" element={<Catalog />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </main>
        </div>
      </div>
    </Router>
  );
};

export default App;
